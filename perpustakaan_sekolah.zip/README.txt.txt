akun user bawaan:
username: verdiansyah
email: e01010010or@gmail.com
password: 12345678

Login bisa menggunakan email/username

akun admin:
username: verdi
password: qwertyuiop

url admin:
localhost/e-perpus/Admin

NOTE:
1. perlu composer install di terminal
2. import sql untuk database